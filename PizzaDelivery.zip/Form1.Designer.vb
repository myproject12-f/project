﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtTel = New System.Windows.Forms.TextBox()
        Me.cmdContinue = New System.Windows.Forms.Button()
        Me.pnlLeft = New System.Windows.Forms.Panel()
        Me.txtOrder = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.txtPostcode = New System.Windows.Forms.TextBox()
        Me.txtTown = New System.Windows.Forms.TextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.txtSurname = New System.Windows.Forms.TextBox()
        Me.txtForename = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pnlRight = New System.Windows.Forms.Panel()
        Me.cmdClear = New System.Windows.Forms.Button()
        Me.lblOrderTotal = New System.Windows.Forms.Label()
        Me.lblDeliveryCharge = New System.Windows.Forms.Label()
        Me.lblOrderValue = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.cmdPrint = New System.Windows.Forms.Button()
        Me.pnlDrinks = New System.Windows.Forms.Panel()
        Me.nudDrk03 = New System.Windows.Forms.NumericUpDown()
        Me.nudDrk02 = New System.Windows.Forms.NumericUpDown()
        Me.nudDrk01 = New System.Windows.Forms.NumericUpDown()
        Me.nudDrk00 = New System.Windows.Forms.NumericUpDown()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.cmdAddItem = New System.Windows.Forms.Button()
        Me.pnlExtras = New System.Windows.Forms.Panel()
        Me.chkExt03 = New System.Windows.Forms.CheckBox()
        Me.chkExt02 = New System.Windows.Forms.CheckBox()
        Me.chkExt01 = New System.Windows.Forms.CheckBox()
        Me.chkExt00 = New System.Windows.Forms.CheckBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.pnlBase = New System.Windows.Forms.Panel()
        Me.radBase02 = New System.Windows.Forms.RadioButton()
        Me.radBase01 = New System.Windows.Forms.RadioButton()
        Me.radBas00 = New System.Windows.Forms.RadioButton()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.pnlTopping = New System.Windows.Forms.Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.radTop02 = New System.Windows.Forms.RadioButton()
        Me.radTop01 = New System.Windows.Forms.RadioButton()
        Me.radTop00 = New System.Windows.Forms.RadioButton()
        Me.prtContinuation = New System.Drawing.Printing.PrintDocument()
        Me.prtDeliveryNote = New System.Drawing.Printing.PrintDocument()
        Me.Panel1.SuspendLayout()
        Me.pnlLeft.SuspendLayout()
        Me.pnlRight.SuspendLayout()
        Me.pnlDrinks.SuspendLayout()
        CType(Me.nudDrk03, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudDrk02, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudDrk01, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudDrk00, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlExtras.SuspendLayout()
        Me.pnlBase.SuspendLayout()
        Me.pnlTopping.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(1, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1219, 104)
        Me.Panel1.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 29.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(456, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(322, 44)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "BUDDY'S PIZZA"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(306, 126)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(144, 22)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "TelePhone No."
        '
        'txtTel
        '
        Me.txtTel.Location = New System.Drawing.Point(490, 126)
        Me.txtTel.Name = "txtTel"
        Me.txtTel.Size = New System.Drawing.Size(218, 20)
        Me.txtTel.TabIndex = 2
        '
        'cmdContinue
        '
        Me.cmdContinue.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdContinue.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cmdContinue.Location = New System.Drawing.Point(749, 130)
        Me.cmdContinue.Name = "cmdContinue"
        Me.cmdContinue.Size = New System.Drawing.Size(132, 32)
        Me.cmdContinue.TabIndex = 3
        Me.cmdContinue.Text = "Continue"
        Me.cmdContinue.UseVisualStyleBackColor = True
        '
        'pnlLeft
        '
        Me.pnlLeft.BackColor = System.Drawing.Color.Transparent
        Me.pnlLeft.Controls.Add(Me.txtOrder)
        Me.pnlLeft.Controls.Add(Me.Label9)
        Me.pnlLeft.Controls.Add(Me.cmdSave)
        Me.pnlLeft.Controls.Add(Me.txtPostcode)
        Me.pnlLeft.Controls.Add(Me.txtTown)
        Me.pnlLeft.Controls.Add(Me.txtAddress)
        Me.pnlLeft.Controls.Add(Me.txtSurname)
        Me.pnlLeft.Controls.Add(Me.txtForename)
        Me.pnlLeft.Controls.Add(Me.Label8)
        Me.pnlLeft.Controls.Add(Me.Label7)
        Me.pnlLeft.Controls.Add(Me.Label6)
        Me.pnlLeft.Controls.Add(Me.Label4)
        Me.pnlLeft.Controls.Add(Me.Label3)
        Me.pnlLeft.Location = New System.Drawing.Point(109, 171)
        Me.pnlLeft.Name = "pnlLeft"
        Me.pnlLeft.Size = New System.Drawing.Size(367, 567)
        Me.pnlLeft.TabIndex = 4
        '
        'txtOrder
        '
        Me.txtOrder.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtOrder.Location = New System.Drawing.Point(3, 356)
        Me.txtOrder.Multiline = True
        Me.txtOrder.Name = "txtOrder"
        Me.txtOrder.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtOrder.Size = New System.Drawing.Size(361, 208)
        Me.txtOrder.TabIndex = 14
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(16, 320)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(139, 25)
        Me.Label9.TabIndex = 13
        Me.Label9.Text = "Order Details"
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.Color.Yellow
        Me.cmdSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSave.ForeColor = System.Drawing.Color.Black
        Me.cmdSave.Location = New System.Drawing.Point(155, 266)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(168, 41)
        Me.cmdSave.TabIndex = 12
        Me.cmdSave.Text = "Save Customer"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'txtPostcode
        '
        Me.txtPostcode.Location = New System.Drawing.Point(185, 200)
        Me.txtPostcode.Name = "txtPostcode"
        Me.txtPostcode.Size = New System.Drawing.Size(138, 20)
        Me.txtPostcode.TabIndex = 11
        '
        'txtTown
        '
        Me.txtTown.Location = New System.Drawing.Point(185, 155)
        Me.txtTown.Name = "txtTown"
        Me.txtTown.Size = New System.Drawing.Size(138, 20)
        Me.txtTown.TabIndex = 10
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(185, 105)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(138, 20)
        Me.txtAddress.TabIndex = 9
        '
        'txtSurname
        '
        Me.txtSurname.Location = New System.Drawing.Point(185, 62)
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.Size = New System.Drawing.Size(138, 20)
        Me.txtSurname.TabIndex = 7
        '
        'txtForename
        '
        Me.txtForename.Location = New System.Drawing.Point(185, 13)
        Me.txtForename.Name = "txtForename"
        Me.txtForename.Size = New System.Drawing.Size(138, 20)
        Me.txtForename.TabIndex = 6
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(25, 203)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(104, 22)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "PIN CODE"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(30, 158)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(45, 22)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "City"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(30, 110)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(83, 22)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Address"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(26, 65)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(105, 22)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Last Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(25, 13)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(107, 22)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "First Name"
        '
        'pnlRight
        '
        Me.pnlRight.BackColor = System.Drawing.Color.Transparent
        Me.pnlRight.Controls.Add(Me.cmdClear)
        Me.pnlRight.Controls.Add(Me.lblOrderTotal)
        Me.pnlRight.Controls.Add(Me.lblDeliveryCharge)
        Me.pnlRight.Controls.Add(Me.lblOrderValue)
        Me.pnlRight.Controls.Add(Me.Label21)
        Me.pnlRight.Controls.Add(Me.Label20)
        Me.pnlRight.Controls.Add(Me.Label19)
        Me.pnlRight.Controls.Add(Me.cmdPrint)
        Me.pnlRight.Controls.Add(Me.pnlDrinks)
        Me.pnlRight.Controls.Add(Me.cmdAddItem)
        Me.pnlRight.Controls.Add(Me.pnlExtras)
        Me.pnlRight.Controls.Add(Me.pnlBase)
        Me.pnlRight.Controls.Add(Me.pnlTopping)
        Me.pnlRight.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnlRight.Location = New System.Drawing.Point(528, 171)
        Me.pnlRight.Name = "pnlRight"
        Me.pnlRight.Size = New System.Drawing.Size(543, 564)
        Me.pnlRight.TabIndex = 5
        '
        'cmdClear
        '
        Me.cmdClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClear.Location = New System.Drawing.Point(39, 495)
        Me.cmdClear.Name = "cmdClear"
        Me.cmdClear.Size = New System.Drawing.Size(141, 46)
        Me.cmdClear.TabIndex = 20
        Me.cmdClear.Text = "Clear"
        Me.cmdClear.UseVisualStyleBackColor = True
        '
        'lblOrderTotal
        '
        Me.lblOrderTotal.AutoSize = True
        Me.lblOrderTotal.ForeColor = System.Drawing.Color.Transparent
        Me.lblOrderTotal.Location = New System.Drawing.Point(440, 491)
        Me.lblOrderTotal.Name = "lblOrderTotal"
        Me.lblOrderTotal.Size = New System.Drawing.Size(82, 25)
        Me.lblOrderTotal.TabIndex = 19
        Me.lblOrderTotal.Text = "Label22"
        '
        'lblDeliveryCharge
        '
        Me.lblDeliveryCharge.AutoSize = True
        Me.lblDeliveryCharge.ForeColor = System.Drawing.Color.Transparent
        Me.lblDeliveryCharge.Location = New System.Drawing.Point(440, 454)
        Me.lblDeliveryCharge.Name = "lblDeliveryCharge"
        Me.lblDeliveryCharge.Size = New System.Drawing.Size(82, 25)
        Me.lblDeliveryCharge.TabIndex = 18
        Me.lblDeliveryCharge.Text = "Label22"
        '
        'lblOrderValue
        '
        Me.lblOrderValue.AutoSize = True
        Me.lblOrderValue.ForeColor = System.Drawing.Color.Transparent
        Me.lblOrderValue.Location = New System.Drawing.Point(439, 416)
        Me.lblOrderValue.Name = "lblOrderValue"
        Me.lblOrderValue.Size = New System.Drawing.Size(82, 25)
        Me.lblOrderValue.TabIndex = 17
        Me.lblOrderValue.Text = "Label22"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label21.Location = New System.Drawing.Point(275, 492)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(122, 25)
        Me.Label21.TabIndex = 16
        Me.Label21.Text = "Order Total"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label20.Location = New System.Drawing.Point(275, 452)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(167, 25)
        Me.Label20.TabIndex = 15
        Me.Label20.Text = "Delivery Charge"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label19.Location = New System.Drawing.Point(275, 416)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(129, 25)
        Me.Label19.TabIndex = 14
        Me.Label19.Text = "Order Value"
        '
        'cmdPrint
        '
        Me.cmdPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPrint.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.cmdPrint.Location = New System.Drawing.Point(36, 442)
        Me.cmdPrint.Name = "cmdPrint"
        Me.cmdPrint.Size = New System.Drawing.Size(170, 37)
        Me.cmdPrint.TabIndex = 8
        Me.cmdPrint.Text = "Print Delivery Note"
        Me.cmdPrint.UseVisualStyleBackColor = True
        '
        'pnlDrinks
        '
        Me.pnlDrinks.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.pnlDrinks.Controls.Add(Me.nudDrk03)
        Me.pnlDrinks.Controls.Add(Me.nudDrk02)
        Me.pnlDrinks.Controls.Add(Me.nudDrk01)
        Me.pnlDrinks.Controls.Add(Me.nudDrk00)
        Me.pnlDrinks.Controls.Add(Me.Label18)
        Me.pnlDrinks.Controls.Add(Me.Label17)
        Me.pnlDrinks.Controls.Add(Me.Label16)
        Me.pnlDrinks.Controls.Add(Me.Label15)
        Me.pnlDrinks.Controls.Add(Me.Label14)
        Me.pnlDrinks.Controls.Add(Me.Label13)
        Me.pnlDrinks.Location = New System.Drawing.Point(14, 248)
        Me.pnlDrinks.Name = "pnlDrinks"
        Me.pnlDrinks.Size = New System.Drawing.Size(250, 174)
        Me.pnlDrinks.TabIndex = 4
        '
        'nudDrk03
        '
        Me.nudDrk03.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudDrk03.ForeColor = System.Drawing.Color.Fuchsia
        Me.nudDrk03.Location = New System.Drawing.Point(173, 143)
        Me.nudDrk03.Name = "nudDrk03"
        Me.nudDrk03.Size = New System.Drawing.Size(74, 23)
        Me.nudDrk03.TabIndex = 9
        '
        'nudDrk02
        '
        Me.nudDrk02.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudDrk02.ForeColor = System.Drawing.Color.Fuchsia
        Me.nudDrk02.Location = New System.Drawing.Point(173, 109)
        Me.nudDrk02.Name = "nudDrk02"
        Me.nudDrk02.Size = New System.Drawing.Size(74, 23)
        Me.nudDrk02.TabIndex = 8
        '
        'nudDrk01
        '
        Me.nudDrk01.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudDrk01.ForeColor = System.Drawing.Color.Fuchsia
        Me.nudDrk01.Location = New System.Drawing.Point(173, 77)
        Me.nudDrk01.Name = "nudDrk01"
        Me.nudDrk01.Size = New System.Drawing.Size(74, 23)
        Me.nudDrk01.TabIndex = 7
        '
        'nudDrk00
        '
        Me.nudDrk00.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudDrk00.ForeColor = System.Drawing.Color.Fuchsia
        Me.nudDrk00.Location = New System.Drawing.Point(173, 43)
        Me.nudDrk00.Name = "nudDrk00"
        Me.nudDrk00.Size = New System.Drawing.Size(74, 23)
        Me.nudDrk00.TabIndex = 6
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(22, 143)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(134, 22)
        Me.Label18.TabIndex = 5
        Me.Label18.Text = "Mineral Water"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(22, 109)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(76, 22)
        Me.Label17.TabIndex = 4
        Me.Label17.Text = "Orange"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(22, 77)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(102, 22)
        Me.Label16.TabIndex = 3
        Me.Label16.Text = "Lemonade"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(22, 46)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(51, 22)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "Cola"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Orange
        Me.Label14.Location = New System.Drawing.Point(169, 10)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(53, 24)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Qnty"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Orange
        Me.Label13.Location = New System.Drawing.Point(18, 10)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(68, 24)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Drinks"
        '
        'cmdAddItem
        '
        Me.cmdAddItem.BackColor = System.Drawing.Color.Transparent
        Me.cmdAddItem.ForeColor = System.Drawing.Color.White
        Me.cmdAddItem.Location = New System.Drawing.Point(187, 191)
        Me.cmdAddItem.Name = "cmdAddItem"
        Me.cmdAddItem.Size = New System.Drawing.Size(137, 35)
        Me.cmdAddItem.TabIndex = 3
        Me.cmdAddItem.Text = "Add Item"
        Me.cmdAddItem.UseVisualStyleBackColor = False
        '
        'pnlExtras
        '
        Me.pnlExtras.BackColor = System.Drawing.Color.Yellow
        Me.pnlExtras.Controls.Add(Me.chkExt03)
        Me.pnlExtras.Controls.Add(Me.chkExt02)
        Me.pnlExtras.Controls.Add(Me.chkExt01)
        Me.pnlExtras.Controls.Add(Me.chkExt00)
        Me.pnlExtras.Controls.Add(Me.Label12)
        Me.pnlExtras.Location = New System.Drawing.Point(360, 32)
        Me.pnlExtras.Name = "pnlExtras"
        Me.pnlExtras.Size = New System.Drawing.Size(149, 153)
        Me.pnlExtras.TabIndex = 2
        '
        'chkExt03
        '
        Me.chkExt03.AutoSize = True
        Me.chkExt03.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkExt03.ForeColor = System.Drawing.Color.Black
        Me.chkExt03.Location = New System.Drawing.Point(12, 126)
        Me.chkExt03.Name = "chkExt03"
        Me.chkExt03.Size = New System.Drawing.Size(89, 24)
        Me.chkExt03.TabIndex = 11
        Me.chkExt03.Text = "Cheese"
        Me.chkExt03.UseVisualStyleBackColor = True
        '
        'chkExt02
        '
        Me.chkExt02.AutoSize = True
        Me.chkExt02.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkExt02.ForeColor = System.Drawing.Color.Black
        Me.chkExt02.Location = New System.Drawing.Point(13, 99)
        Me.chkExt02.Name = "chkExt02"
        Me.chkExt02.Size = New System.Drawing.Size(110, 24)
        Me.chkExt02.TabIndex = 10
        Me.chkExt02.Text = "Anchovies"
        Me.chkExt02.UseVisualStyleBackColor = True
        '
        'chkExt01
        '
        Me.chkExt01.AutoSize = True
        Me.chkExt01.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkExt01.ForeColor = System.Drawing.Color.Black
        Me.chkExt01.Location = New System.Drawing.Point(12, 73)
        Me.chkExt01.Name = "chkExt01"
        Me.chkExt01.Size = New System.Drawing.Size(149, 24)
        Me.chkExt01.TabIndex = 9
        Me.chkExt01.Text = "Green Peppers"
        Me.chkExt01.UseVisualStyleBackColor = True
        '
        'chkExt00
        '
        Me.chkExt00.AutoSize = True
        Me.chkExt00.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkExt00.ForeColor = System.Drawing.Color.Black
        Me.chkExt00.Location = New System.Drawing.Point(13, 49)
        Me.chkExt00.Name = "chkExt00"
        Me.chkExt00.Size = New System.Drawing.Size(120, 24)
        Me.chkExt00.TabIndex = 8
        Me.chkExt00.Text = "Mushrooms"
        Me.chkExt00.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Red
        Me.Label12.Location = New System.Drawing.Point(38, 11)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(73, 25)
        Me.Label12.TabIndex = 7
        Me.Label12.Text = "Extras"
        '
        'pnlBase
        '
        Me.pnlBase.BackColor = System.Drawing.Color.MidnightBlue
        Me.pnlBase.Controls.Add(Me.radBase02)
        Me.pnlBase.Controls.Add(Me.radBase01)
        Me.pnlBase.Controls.Add(Me.radBas00)
        Me.pnlBase.Controls.Add(Me.Label11)
        Me.pnlBase.Location = New System.Drawing.Point(187, 32)
        Me.pnlBase.Name = "pnlBase"
        Me.pnlBase.Size = New System.Drawing.Size(149, 153)
        Me.pnlBase.TabIndex = 1
        '
        'radBase02
        '
        Me.radBase02.AutoSize = True
        Me.radBase02.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radBase02.ForeColor = System.Drawing.Color.White
        Me.radBase02.Location = New System.Drawing.Point(17, 104)
        Me.radBase02.Name = "radBase02"
        Me.radBase02.Size = New System.Drawing.Size(124, 24)
        Me.radBase02.TabIndex = 10
        Me.radBase02.TabStop = True
        Me.radBase02.Text = "35 cm/14 in."
        Me.radBase02.UseVisualStyleBackColor = True
        '
        'radBase01
        '
        Me.radBase01.AutoSize = True
        Me.radBase01.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radBase01.ForeColor = System.Drawing.Color.White
        Me.radBase01.Location = New System.Drawing.Point(17, 76)
        Me.radBase01.Name = "radBase01"
        Me.radBase01.Size = New System.Drawing.Size(124, 24)
        Me.radBase01.TabIndex = 9
        Me.radBase01.TabStop = True
        Me.radBase01.Text = "30 cm/12 in."
        Me.radBase01.UseVisualStyleBackColor = True
        '
        'radBas00
        '
        Me.radBas00.AutoSize = True
        Me.radBas00.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radBas00.ForeColor = System.Drawing.Color.White
        Me.radBas00.Location = New System.Drawing.Point(17, 49)
        Me.radBas00.Name = "radBas00"
        Me.radBas00.Size = New System.Drawing.Size(124, 24)
        Me.radBas00.TabIndex = 8
        Me.radBas00.TabStop = True
        Me.radBas00.Text = "25 cm/10 in."
        Me.radBas00.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Red
        Me.Label11.Location = New System.Drawing.Point(46, 11)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(61, 25)
        Me.Label11.TabIndex = 7
        Me.Label11.Text = "Base"
        '
        'pnlTopping
        '
        Me.pnlTopping.BackColor = System.Drawing.Color.SeaGreen
        Me.pnlTopping.Controls.Add(Me.Label10)
        Me.pnlTopping.Controls.Add(Me.radTop02)
        Me.pnlTopping.Controls.Add(Me.radTop01)
        Me.pnlTopping.Controls.Add(Me.radTop00)
        Me.pnlTopping.Location = New System.Drawing.Point(14, 32)
        Me.pnlTopping.Name = "pnlTopping"
        Me.pnlTopping.Size = New System.Drawing.Size(149, 153)
        Me.pnlTopping.TabIndex = 0
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Red
        Me.Label10.Location = New System.Drawing.Point(32, 11)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(91, 25)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "Topping"
        '
        'radTop02
        '
        Me.radTop02.AutoSize = True
        Me.radTop02.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radTop02.ForeColor = System.Drawing.Color.White
        Me.radTop02.Location = New System.Drawing.Point(11, 101)
        Me.radTop02.Name = "radTop02"
        Me.radTop02.Size = New System.Drawing.Size(118, 24)
        Me.radTop02.TabIndex = 2
        Me.radTop02.TabStop = True
        Me.radTop02.Text = "Meat Feast"
        Me.radTop02.UseVisualStyleBackColor = True
        '
        'radTop01
        '
        Me.radTop01.AutoSize = True
        Me.radTop01.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radTop01.ForeColor = System.Drawing.Color.White
        Me.radTop01.Location = New System.Drawing.Point(11, 76)
        Me.radTop01.Name = "radTop01"
        Me.radTop01.Size = New System.Drawing.Size(139, 24)
        Me.radTop01.TabIndex = 1
        Me.radTop01.TabStop = True
        Me.radTop01.Text = "Four Seasons"
        Me.radTop01.UseVisualStyleBackColor = True
        '
        'radTop00
        '
        Me.radTop00.AutoSize = True
        Me.radTop00.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radTop00.ForeColor = System.Drawing.Color.White
        Me.radTop00.Location = New System.Drawing.Point(13, 49)
        Me.radTop00.Name = "radTop00"
        Me.radTop00.Size = New System.Drawing.Size(113, 24)
        Me.radTop00.TabIndex = 0
        Me.radTop00.TabStop = True
        Me.radTop00.Text = "Margherita"
        Me.radTop00.UseVisualStyleBackColor = True
        '
        'prtContinuation
        '
        '
        'prtDeliveryNote
        '
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.$safeprojectname$.My.Resources.Resources._1
        Me.ClientSize = New System.Drawing.Size(1110, 750)
        Me.Controls.Add(Me.pnlRight)
        Me.Controls.Add(Me.pnlLeft)
        Me.Controls.Add(Me.cmdContinue)
        Me.Controls.Add(Me.txtTel)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.pnlLeft.ResumeLayout(False)
        Me.pnlLeft.PerformLayout()
        Me.pnlRight.ResumeLayout(False)
        Me.pnlRight.PerformLayout()
        Me.pnlDrinks.ResumeLayout(False)
        Me.pnlDrinks.PerformLayout()
        CType(Me.nudDrk03, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudDrk02, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudDrk01, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudDrk00, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlExtras.ResumeLayout(False)
        Me.pnlExtras.PerformLayout()
        Me.pnlBase.ResumeLayout(False)
        Me.pnlBase.PerformLayout()
        Me.pnlTopping.ResumeLayout(False)
        Me.pnlTopping.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtTel As System.Windows.Forms.TextBox
    Friend WithEvents cmdContinue As System.Windows.Forms.Button
    Friend WithEvents pnlLeft As System.Windows.Forms.Panel
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents pnlRight As System.Windows.Forms.Panel
    Friend WithEvents pnlExtras As System.Windows.Forms.Panel
    Friend WithEvents pnlBase As System.Windows.Forms.Panel
    Friend WithEvents pnlTopping As System.Windows.Forms.Panel
    Friend WithEvents txtTown As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtSurname As System.Windows.Forms.TextBox
    Friend WithEvents txtForename As System.Windows.Forms.TextBox
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents txtPostcode As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtOrder As System.Windows.Forms.TextBox
    Friend WithEvents radTop02 As System.Windows.Forms.RadioButton
    Friend WithEvents radTop01 As System.Windows.Forms.RadioButton
    Friend WithEvents radTop00 As System.Windows.Forms.RadioButton
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents chkExt00 As System.Windows.Forms.CheckBox
    Friend WithEvents radBase02 As System.Windows.Forms.RadioButton
    Friend WithEvents radBase01 As System.Windows.Forms.RadioButton
    Friend WithEvents radBas00 As System.Windows.Forms.RadioButton
    Friend WithEvents chkExt03 As System.Windows.Forms.CheckBox
    Friend WithEvents chkExt02 As System.Windows.Forms.CheckBox
    Friend WithEvents chkExt01 As System.Windows.Forms.CheckBox
    Friend WithEvents cmdAddItem As System.Windows.Forms.Button
    Friend WithEvents pnlDrinks As System.Windows.Forms.Panel
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents nudDrk03 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudDrk02 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudDrk01 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudDrk00 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lblOrderTotal As System.Windows.Forms.Label
    Friend WithEvents lblDeliveryCharge As System.Windows.Forms.Label
    Friend WithEvents lblOrderValue As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents cmdPrint As System.Windows.Forms.Button
    Friend WithEvents cmdClear As System.Windows.Forms.Button
    Friend WithEvents prtContinuation As System.Drawing.Printing.PrintDocument
    Friend WithEvents prtDeliveryNote As System.Drawing.Printing.PrintDocument

End Class
